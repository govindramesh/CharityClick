https://developer.chrome.com/docs/extensions/mv3/getstarted/tut-reading-time/
